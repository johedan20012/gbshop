<?php

namespace App\Http\Controllers;

use App\Producto;
use App\Categoria;
use App\FotosProducto;
use Illuminate\Http\Request;

class ProductosController extends Controller
{
    /**
     * Muestra todos los productos
     *
     * @return Productos
     */
    public function getCatalogoPorCategoria(Request $request)
    {
        $validatedData = $request->validate([
            'id' => 'nullable|integer|digits_between:1,10'
        ]);
        if($request->input('id') !== null){
            $id = $request->input('id');
        }else{
            $id=0;
        }

        if($id == 0){
            $productos = Producto::paginate(5)
            ->setPageName("p");
        }else{
            $productos = Producto::whereIn('idcategoria',function($query2) use ($id){
                            $query2->select('idcategorias')->from('categorias')->where('idcategoriapadre',$id);
                        })->orWhere('idcategoria',$id)
                        ->paginate(5)
                        ->setPageName("p");
        }
        /*return view('widgets.tablaProductos', ['productos' => $productos]);

        $productos = Producto::paginate(5)->setPageName("p");*/

        if($request->ajax()){
            if($id != 0){
                $categoria = Categoria::find($id);
                $padre = $categoria->padre;
                if($padre != null){
                    $categoria =$padre->nombre." ".$categoria->nombre;
                }else{
                    $categoria =$categoria->nombre;
                }
            }else{
                $categoria = "Todos";
            }

            return view('widgets.tablaProductos', ['productos' => $productos,'categoria' => $categoria]);
        }

        return view('catalogo', ['productos' => $productos /*Producto::all()*/, 'categorias' => Categoria::all()->where('idcategoriapadre',null)]);
    }

    /**
     * Muestra todos los productos por categoria, si la categoria es 0 regresa todos los productos
     *
     * @return Productos
     */

    public function getProductosPorCategoria(Request $request){
        
    }

    public function getProducto(Request $request){
        $validatedData = $request->validate([
            'code' => 'nullable|string'
        ]);


        if($request->input('code') !== null){
            $codigo = $request->input('code');

            $producto = Producto::where('codigo',$codigo)->first();

            if($producto == null){
                return view('extras.error')->withErrors(["error" => "Producto inexistente"]);
            }
        }else{
            return view('extras.error')->withErrors(["error" => "Producto inexistente"]);
        }
        
        return view('producto', ['producto' => $producto]);
    }
}